# evaluate_rel.py
import json
from utils import extract_relationships

with open("test_rel.jsonl", "r", encoding="utf-8") as f:
    lines = [json.loads(l) for l in f if l.strip()]

tp = fp = fn = 0

for item in lines:
    preds = extract_relationships(item["text"])
    gold = item["expect"]

    pred_set = {(p["subject"].lower(), p["verb"].lower(), p["object"].lower()) for p in preds}
    gold_set = {(g["subject"].lower(), g["verb"].lower(), g["object"].lower()) for g in gold}

    tp += len(pred_set & gold_set)
    fp += len(pred_set - gold_set)
    fn += len(gold_set - pred_set)

precision = tp / (tp + fp + 1e-9)
recall = tp / (tp + fn + 1e-9)
f1 = 2 * precision * recall / (precision + recall + 1e-9)

print("\n=== Relationship Extraction Accuracy ===")
print("Precision:", round(precision, 3))
print("Recall:", round(recall, 3))
print("F1 Score:", round(f1, 3))
print("TP:", tp, "FP:", fp, "FN:", fn)
