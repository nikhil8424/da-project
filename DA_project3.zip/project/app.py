import streamlit as st
from data_loader import load_cuad, build_clause_library
from model import find_similar_clause
from utils import extract_relationships, clean_text, split_into_clauses

st.set_page_config(page_title="Legal NLP Analyzer", layout="wide")

st.title("📄 AI-Powered Legal NLP Analyzer")
st.write("Contract Clause Identification + Relationship Extraction")


# --- LOAD CUAD DATA ---
@st.cache_resource
def load_library():
    df = load_cuad(r"C:\Users\NIKHIL GUPTA\Desktop\project\CUAD.csv") 
    return build_clause_library(df)

clause_library = load_library()


# --- MAIN INPUT ---
text_input = st.text_area("Paste a contract section:", height=250)

if st.button("Analyze"):

    if len(text_input.strip()) < 20:
        st.warning("Please enter a larger contract section!")
        st.stop()

    cleaned = clean_text(text_input)

    # -------------------------------------------------------------
    # 1️⃣ CLAUSE IDENTIFICATION (Semantic)
    # -------------------------------------------------------------
    st.header("1️⃣ Clause Identification (Semantic)")

    clauses = split_into_clauses(cleaned)

    if not clauses:
        st.info("Could not detect clauses. Try providing a longer section.")
    else:
        for cl in clauses:
            pred, score = find_similar_clause(cl, clause_library)

            st.write(f"### 📝 Clause")
            st.write(f"{cl}")

            st.success(f"**Predicted Type:** {pred}")
            st.write(f"**Confidence:** `{round(score, 3)}`")
            st.markdown("---")

    # -------------------------------------------------------------
    # 2️⃣ LEGAL RELATIONSHIP EXTRACTION (Syntax + Semantic)
    # -------------------------------------------------------------
    st.header("2️⃣ Legal Relationship Extraction")

    relations = extract_relationships(cleaned)

    if relations:
        for r in relations:
            st.write(f"• **{r['subject']}** —[{r['verb']}]→ **{r['object']}**")
    else:
        st.info("No subject–verb–object relationships detected.")
