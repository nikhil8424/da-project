import re
import json
import spacy
import numpy as np
import nltk

from sklearn.metrics.pairwise import cosine_similarity

# ------------------------------------------------------------
# Load spaCy Large Transformer Model (Used for Dependency Parsing)
# ------------------------------------------------------------
try:
    nlp = spacy.load("en_core_web_trf")
except:
    raise Exception("⚠️ spaCy model 'en_core_web_trf' not found. Install using:\n\npython -m spacy download en_core_web_trf")

# Download tokenizer
nltk.download("punkt")


# ------------------------------------------------------------
# BASIC TEXT CLEANING
# ------------------------------------------------------------
def clean_text(text):
    if text is None:
        return ""
    text = re.sub(r"\s+", " ", text)
    return text.strip()


# ------------------------------------------------------------
# CLAUSE SPLITTING (fix for Part 1)
# ------------------------------------------------------------
def split_into_clauses(text):
    """
    Split large legal text into meaningful clauses.
    Uses NLTK’s sentence tokenizer + length filtering.
    """
    sentences = nltk.sent_tokenize(text)

    clauses = []
    for s in sentences:
        s = s.strip()
        # Keep only meaningful sentences
        if len(s) > 30:
            clauses.append(s)

    return clauses


# ------------------------------------------------------------
# EMBEDDING SIMILARITY
# ------------------------------------------------------------
def cosine_sim(vec1, vec2):
    """
    Compute cosine similarity between two embedding vectors.
    """
    vec1 = np.array(vec1).reshape(1, -1)
    vec2 = np.array(vec2).reshape(1, -1)
    return cosine_similarity(vec1, vec2)[0][0]


# ------------------------------------------------------------
# CLAUSE GROUP MAPPING (CUAD → High Level Types)
# ------------------------------------------------------------
CLAUSE_GROUPS = {
    "Termination": [
        "Termination For Convenience",
        "Notice Period To Terminate Renewal",
    ],
    "Governing Law": ["Governing Law"],
    "Non-Compete": [
        "Non-Compete",
        "No-Solicit Of Customers",
        "No-Solicit Of Employees"
    ],
    "IP": [
        "Ip Ownership Assignment",
        "Joint Ip Ownership",
        "License Grant",
        "Irrevocable Or Perpetual License",
    ],
    "Liability": [
        "Uncapped Liability",
        "Cap On Liability",
        "Liquidated Damages"
    ]
}

def map_cuad_to_group(cuad_key):
    for group, keys in CLAUSE_GROUPS.items():
        if cuad_key in keys:
            return group
    return "Other"


# ------------------------------------------------------------
# RELATIONSHIP EXTRACTION (Dependency Parsing)
# ------------------------------------------------------------
def extract_relationships(text):
    """
    Dependency-based extraction of:
    • Subject (nsubj)
    • Verb
    • Object (dobj, pobj)

    Produces legal relationships like:
    Party —[grants]→ license
    """
    doc = nlp(text)
    relations = []

    for token in doc:
        if token.pos_ == "VERB":

            # subject of verb
            subject = [
                child.text for child in token.children
                if child.dep_ in ("nsubj", "nsubjpass")
            ]

            # object of verb
            obj = [
                child.text for child in token.children
                if child.dep_ in ("dobj", "pobj")
            ]

            if subject and obj:
                relations.append({
                    "verb": token.text,
                    "subject": subject[0],
                    "object": obj[0]
                })

    return relations
