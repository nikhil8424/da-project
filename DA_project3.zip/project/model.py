# model.py
import torch
from transformers import AutoTokenizer, AutoModel
from utils import clean_text, cosine_sim
from scipy.spatial.distance import cdist

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

MODEL_NAME = "nlpaueb/legal-bert-base-uncased"   # Legal-BERT for semantic tasks

tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModel.from_pretrained(MODEL_NAME).to(DEVICE)


# ---- EMBEDDING FUNCTION ----
def get_embedding(text):
    text = clean_text(text)
    inputs = tokenizer(text, return_tensors="pt", truncation=True, padding="max_length", max_length=256).to(DEVICE)
    with torch.no_grad():
        outputs = model(**inputs)
    # CLS token
    return outputs.last_hidden_state[:, 0, :].cpu().numpy().flatten()


# ---- CLAUSE IDENTIFICATION using SEMANTIC SIMILARITY ----
def find_similar_clause(text, clause_library, threshold=0.70):
    """
    Compare new section of contract against all clause exemplars
    to identify which clause type it belongs to.
    """
    new_vec = get_embedding(text)

    best_group = None
    best_score = 0

    for group, samples in clause_library.items():
        sample_vecs = [item["vec"] for item in samples]
        sims = [cosine_sim(new_vec, v) for v in sample_vecs]

        avg_sim = sum(sims) / len(sims)

        if avg_sim > best_score:
            best_score = avg_sim
            best_group = group

    if best_score > threshold:
        return best_group, best_score
    return "Unknown", best_score
