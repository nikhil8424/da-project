import pandas as pd
from utils import clean_text, map_cuad_to_group


# ------------------------------------------------------------
# Load CUAD CSV
# ------------------------------------------------------------
def load_cuad(csv_path):
    """
    Loads the CUAD dataset into a DataFrame.
    """
    df = pd.read_csv(csv_path)
    return df


# ------------------------------------------------------------
# (OPTIONAL) Direct clause extractor – currently not used
# ------------------------------------------------------------
def load_clause_library(csv_path):
    """
    Extracts raw clause examples from the CUAD CSV.
    Filters out short / useless values (Yes/No/etc.).
    """
    df = pd.read_csv(csv_path)

    clause_library = []

    clause_columns = [c for c in df.columns if c not in ["filename", "id"]]

    for col in clause_columns:
        for val in df[col].dropna():
            text = str(val).strip()

            # Filter bad values
            if text.lower() in ["yes", "no", "n/a", "not mentioned", "none", ""]:
                continue

            if len(text) < 50:  
                continue

            clause_library.append({
                "clause_type": col,
                "text": text
            })

    print(f"[INFO] Loaded {len(clause_library)} high-quality clause exemplars.")
    return clause_library


# ------------------------------------------------------------
# HIGH-LEVEL SEMANTIC GROUP LIBRARY (Used by Streamlit App)
# ------------------------------------------------------------
from model import get_embedding

def build_clause_library(df):
    library = {}

    for col in df.columns:
        if col.endswith("-Answer"):
            base_col = col.replace("-Answer", "")
            group = map_cuad_to_group(base_col)

            sample_texts = df[col].dropna().astype(str).tolist()
            sample_texts = [clean_text(t) for t in sample_texts if len(t) > 20]

            if group not in library:
                library[group] = []

            # ADD EMBEDDINGS HERE ONLY ONCE
            for t in sample_texts[:20]:
                library[group].append({
                    "text": t,
                    "vec": get_embedding(t)
                })

    return library
