
# File: app.py
"""
Streamlit application that ties everything together.
Four main actions in the UI:
- Upload CUAD-like CSV
- Preview dataset
- Train model (with progress)
- Predict on custom text / candidates

Note: For a production deployment or larger datasets, replace the simple scikit pipeline
with a transformer-based model (Hugging Face) and proper training schedule.
"""
import streamlit as st
import pandas as pd 
from data_prep import load_cuad_style_csv, make_pairwise_dataframe, build_train_test, INFO_MD 
from model import train_model, evaluate_model, predict_best, save_model, load_model
import os

st.set_page_config(page_title="Automated Contract Provision Extraction", layout='wide') 
st.markdown(INFO_MD) 

st.title("Automated Contract Provision Extraction — CUAD / LexGLUE style")

# Sidebar: upload & training controls
st.sidebar.header('1) Dataset')
uploaded = st.sidebar.file_uploader('Upload CUAD-style CSV', type=['csv'])
context_col = st.sidebar.text_input('context column name', value='context')
endings_col = st.sidebar.text_input('endings column name', value='endings')
label_col = st.sidebar.text_input('label column name', value='label')

st.sidebar.header('2) Model')
max_features = st.sidebar.number_input('TF-IDF max features', min_value=1000, max_value=50000, value=20000, step=1000)
train_btn = st.sidebar.button('Train model')
load_btn = st.sidebar.button('Load model from disk')
model_path = st.sidebar.text_input('Model path', value='contract_extractor.joblib')

model = None

if uploaded is not None:
    df_raw = load_cuad_style_csv(uploaded, context_col=context_col, endings_col=endings_col, label_col=label_col)
    st.subheader('Dataset preview')
    st.write(df_raw.head())
    # prepare pairwise
    with st.spinner('Preparing pairwise dataset...'):
        pairwise = make_pairwise_dataframe(df_raw, context_col=context_col, endings_col=endings_col, label_col=label_col)
        train_df, test_df = build_train_test(pairwise, test_size=0.15)
    st.write('Pairwise examples:', len(pairwise), 'Train questions:', train_df['question_id'].nunique(), 'Test questions:', test_df['question_id'].nunique())

    if train_btn:
        with st.spinner('Training model — this may take a moment'):
            pipe = train_model(train_df, max_features=max_features)
            acc = evaluate_model(pipe, test_df)
            st.success(f'Training complete — question-level accuracy on test set: {acc:.3f}')
            save_model(pipe, model_path)
            st.info(f'Model saved to {model_path}')
            model = pipe

    if load_btn:
        if os.path.exists(model_path):
            model = load_model(model_path)
            st.success(f'Loaded model from {model_path}')
        else:
            st.error('Model file not found — train first or supply correct path')

else:
    st.info('Upload a CUAD-style CSV in the sidebar to get started.')

# Inference UI
st.header('Try it: single example prediction')
user_context = st.text_area('Paste a contract paragraph / context here', height=200)
user_candidates_raw = st.text_area('Paste candidate endings (one per line)')
if st.button('Predict best candidate'):
    if model is None:
        # try to load model if exists
        if os.path.exists(model_path):
            model = load_model(model_path)
            st.success(f'Loaded model from {model_path}')
        else:
            st.error('No model available. Upload dataset and train or load a saved model.')
    if model is not None:
        candidates = [c.strip() for c in user_candidates_raw.splitlines() if c.strip()]
        if len(candidates) == 0:
            st.error('Provide at least one candidate ending (one per line).')
        else:
            best_idx, best_text, scores = predict_best(model, user_context, candidates)
            st.write('Best candidate index:', best_idx)
            st.write('Best candidate text:')
            st.write(best_text)
            st.write('All scores (higher -> more likely):')
            for i, s in enumerate(scores):
                st.write(i, s, candidates[i])
