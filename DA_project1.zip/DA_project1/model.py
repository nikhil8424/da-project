# File: model.py
"""
Model training & inference utilities.
Uses a TF-IDF vectorizer + LogisticRegression as a binary scorer.
During inference we score each candidate and pick the highest scoring one.
"""
import joblib
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
import numpy as np


def build_pipeline(max_features=20000):
    pipe = Pipeline([
        ('tfidf', TfidfVectorizer(max_features=max_features, ngram_range=(1,2), strip_accents='unicode')),
        ('clf', LogisticRegression(max_iter=200, class_weight='balanced'))
    ])
    return pipe


def train_model(train_df, max_features=20000):
    """Train and return a pipeline fit on train_df (expects columns 'text' and 'is_correct')."""
    X = train_df['text'].astype(str).tolist()
    y = train_df['is_correct'].astype(int).tolist()
    pipe = build_pipeline(max_features=max_features)
    pipe.fit(X, y)
    return pipe


def evaluate_model(pipe, test_df):
    """Evaluate at the question level: for each question, pick candidate with highest score."""
    # predict probabilities or decision function
    X = test_df['text'].astype(str).tolist()
    # use predict_proba if available
    if hasattr(pipe, 'predict_proba'):
        probs = pipe.predict_proba(X)[:,1]
    else:
        probs = pipe.decision_function(X)
    test_df = test_df.copy()
    test_df['score'] = probs
    # group by question and choose argmax candidate
    grouped = test_df.groupby('question_id')
    preds = []
    golds = []
    for qid, g in grouped:
        pred_idx = int(g.loc[g['score'].idxmax()]['candidate_index'])
        # gold index is where is_correct==1
        gold_row = g[g['is_correct']==1]
        if len(gold_row)==0:
            # defensive: treat as incorrect
            gold_idx = -1
        else:
            gold_idx = int(gold_row['candidate_index'].iloc[0])
        preds.append(pred_idx)
        golds.append(gold_idx)
    # compute accuracy
    preds = np.array(preds)
    golds = np.array(golds)
    acc = (preds == golds).mean()
    return acc


def predict_best(pipe, context, candidates):
    """Given a context (string) and list of candidate strings, return index and text of best candidate and scores.
    """
    items = [str(context) + " \n[Candidate] " + str(c) for c in candidates]
    if hasattr(pipe, 'predict_proba'):
        probs = pipe.predict_proba(items)[:,1]
    else:
        probs = pipe.decision_function(items)
    best_idx = int(np.argmax(probs))
    return best_idx, candidates[best_idx], probs.tolist()


def save_model(pipe, path):
    joblib.dump(pipe, path)


def load_model(path):
    return joblib.load(path)

