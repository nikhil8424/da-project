# File: data_prep.py
""" 
Utilities to load CUAD-like dataset (context, endings, label) and convert into 
training instances suitable for a multiple-choice classification approach. 
Each (context, candidate) pair becomes one example with binary label: 1 if 
candidate is the correct ending, else 0. During inference we score each 
candidate and choose the one with the highest probability. 
""" 
import ast 
import pandas as pd 
from sklearn.model_selection import train_test_split 


def parse_endings(endings_cell):
    """Parse a string representation of a Python list into a list of strings.
    Falls back to simple splitting if literal_eval fails."""
    if isinstance(endings_cell, list):
        return endings_cell
    try:
        return ast.literal_eval(endings_cell)
    except Exception:
        # try some heuristics: remove surrounding quotes/brackets then split on "' '"
        s = str(endings_cell).strip()
        if s.startswith("[") and s.endswith("]"):
            s = s[1:-1]
        # split on comma while preserving internal commas roughly
        parts = [p.strip().strip("\"\'") for p in s.split("','")]
        return parts


def load_cuad_style_csv(path, context_col='context', endings_col='endings', label_col='label'):
    """Load CSV and parse endings column into lists."""
    df = pd.read_csv(path)
    df = df[[context_col, endings_col, label_col]].copy()
    df[endings_col] = df[endings_col].apply(parse_endings)
    return df


def make_pairwise_dataframe(df, context_col='context', endings_col='endings', label_col='label'):
    """Convert each multi-choice row into multiple (context + candidate) rows.
    Returns dataframe with columns: text (context + ' ' + candidate), is_correct (0/1), question_id, candidate_index
    """
    rows = []
    for qi, row in df.reset_index(drop=True).iterrows():
        context = str(row[context_col])
        candidates = row[endings_col]
        correct_idx = int(row[label_col])
        for ci, cand in enumerate(candidates):
            text = context + " \n[Candidate] " + str(cand)
            rows.append({
                'question_id': qi,
                'candidate_index': ci,
                'text': text,
                'is_correct': 1 if ci == correct_idx else 0
            })
    return pd.DataFrame(rows)


def build_train_test(df, test_size=0.15, random_state=42):
    """Split by question rows (not by pair entries) to avoid leakage."""
    # First split question ids
    qids = df['question_id'].unique()
    train_q, test_q = train_test_split(qids, test_size=test_size, random_state=random_state)
    train_df = df[df['question_id'].isin(train_q)].reset_index(drop=True)
    test_df = df[df['question_id'].isin(test_q)].reset_index(drop=True)
    return train_df, test_df

 
# Quick tips / explanation copied for display in the app (kept as a constant to avoid 
# executing Streamlit calls on import). 
INFO_MD = """ 
**How this works (simple baseline):** 
- We convert each (context + candidate) pair into a text example and train a binary classifier 
  to score how well a candidate completes the context. 
- At inference we score each candidate and pick the highest scoring one as the predicted clause type. 
 
**Notes & next steps:** 
- This baseline uses TF-IDF + Logistic Regression; to improve, switch to a transformer (e.g. `sentence-transformers` or Hugging Face `transformers`) and fine-tune on the dataset. 
- If your dataset is multi-label (more than one correct candidate), adjust the training target accordingly. 
""" 
