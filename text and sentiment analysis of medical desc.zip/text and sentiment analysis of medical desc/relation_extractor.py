from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional
import re

from spacy.tokens import Doc, Span, Token

from preprocessing import preprocess_text


@dataclass
class MedicalEvent:
    sentence: str
    actor: Optional[str] = None
    action: Optional[str] = None
    object: Optional[str] = None
    target: Optional[str] = None
    dosage: Optional[str] = None
    reason: Optional[str] = None
    event_type: Optional[str] = None  # To be filled by classifier if desired.

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


KNOWN_DRUGS = {
    "amoxicillin",
    "paracetamol",
    "acetaminophen",
    "ibuprofen",
    "metformin",
}

DOSAGE_PATTERN = re.compile(
    r"\b\d+(\.\d+)?\s*(mg|mcg|g|ml|units|tablets?|capsules?)\b",
    flags=re.IGNORECASE,
)


def _span_text(span_tokens: List[Token]) -> str:
    return " ".join(t.text for t in span_tokens).strip()


def _find_dosage(text: str) -> Optional[str]:
    match = DOSAGE_PATTERN.search(text)
    if match:
        return match.group(0)
    return None


def _extract_entities_for_sentence(doc: Doc, sent: Span) -> Dict[str, List[str]]:
    doctors: List[str] = []
    drugs: List[str] = []
    diseases: List[str] = []
    dosages: List[str] = []
    times: List[str] = []

    for ent in doc.ents:
        if ent.start < sent.start or ent.end > sent.end:
            continue

        label = ent.label_.upper()
        text = ent.text
        if label == "PERSON" and ("dr" in text.lower() or "doctor" in text.lower()):
            doctors.append(text)
        elif label in {"DRUG", "CHEMICAL", "MEDICATION"}:
            drugs.append(text)
        elif label in {"DISEASE", "CONDITION", "PROBLEM", "DIAGNOSIS"}:
            diseases.append(text)
        elif label in {"DATE", "TIME"}:
            times.append(text)

    # Heuristic drug detection if NER did not find any.
    if not drugs:
        for token in sent:
            if (
                token.text.lower() in KNOWN_DRUGS
                or token.text[0].isupper()
                and token.pos_ in {"NOUN", "PROPN"}
            ):
                drugs.append(token.text)

    # Dosage from regex on sentence text.
    dosage = _find_dosage(sent.text)
    if dosage:
        dosages.append(dosage)

    # Simple heuristic for disease / reason terms.
    if not diseases:
        for token in sent:
            if token.lemma_.lower() in {"infection", "pneumonia", "diabetes", "hypertension"}:
                diseases.append(token.text)

    return {
        "doctors": doctors,
        "drugs": drugs,
        "diseases": diseases,
        "dosages": dosages,
        "times": times,
    }


def _get_actor_and_target(sent: Span, entities: Dict[str, List[str]]) -> (Optional[str], Optional[str]):
    actor: Optional[str] = None
    target: Optional[str] = None

    # Prefer explicit doctor entity as actor.
    if entities["doctors"]:
        actor = entities["doctors"][0]

    # Look for patient-like tokens as target.
    for token in sent:
        if token.lemma_.lower() == "patient":
            target = token.text
            break

    # Use dependency labels to refine actor / target.
    root_verbs = [t for t in sent if t.dep_ == "ROOT" and t.pos_.startswith("V")]
    root = root_verbs[0] if root_verbs else None

    if root:
        for child in root.children:
            if child.dep_ in {"nsubj", "nsubjpass"}:
                phrase_tokens = list(child.subtree)
                phrase = _span_text(phrase_tokens)
                if child.lemma_.lower() == "patient":
                    target = phrase
                elif actor is None:
                    actor = phrase

        # Agent in passive voice (e.g., "by Dr. Sharma").
        for child in root.children:
            if child.dep_ == "agent":  # usually the "by" preposition
                for sub in child.subtree:
                    if sub.ent_type_ == "PERSON" or sub.text.lower().startswith("dr"):
                        actor = _span_text(list(child.subtree))
                        break

    return actor, target


def _get_action(sent: Span) -> Optional[str]:
    # Prefer the main verb (ROOT).
    for token in sent:
        if token.dep_ == "ROOT" and token.pos_.startswith("V"):
            return token.lemma_
    # Fallback to any verb.
    for token in sent:
        if token.pos_.startswith("V"):
            return token.lemma_
    return None


def _get_object(sent: Span, entities: Dict[str, List[str]]) -> Optional[str]:
    # Heuristic: object of main verb (dobj) or relevant noun near dosage/drug.
    root_verbs = [t for t in sent if t.dep_ == "ROOT" and t.pos_.startswith("V")]
    root = root_verbs[0] if root_verbs else None

    if root:
        candidates: List[str] = []
        for child in root.children:
            if child.dep_ in {"dobj", "attr", "pobj"}:
                candidates.append(_span_text(list(child.subtree)))
        if candidates:
            return candidates[0]

    # If a drug is present, treat it as object.
    if entities["drugs"]:
        return entities["drugs"][0]

    return None


def _get_reason(sent: Span, entities: Dict[str, List[str]]) -> Optional[str]:
    # Prefer disease entities.
    if entities["diseases"]:
        return entities["diseases"][0]

    # Look for "due to", "because of", "for" phrases.
    lowered = sent.text.lower()
    for pattern in ["due to", "because of"]:
        if pattern in lowered:
            idx = lowered.index(pattern) + len(pattern)
            reason = sent.text[idx:].strip(" .,:;")
            if reason:
                return reason

    # Simple "for <reason>" heuristic.
    for token in sent:
        if token.text.lower() == "for" and token.head.pos_.startswith("V"):
            reason_span = _span_text(list(token.subtree)[1:])
            if reason_span:
                return reason_span

    return None


def extract_medical_relations(text: str) -> Dict[str, Any]:
    """
    Analyze clinical text and extract structured medical relationships.

    Returns JSON-serializable dict of the form:
    {
        "text": original_text,
        "events": [
            {
                "sentence": "...",
                "actor": "...",
                "action": "...",
                "object": "...",
                "target": "...",
                "dosage": "...",
                "reason": "...",
                "event_type": null
            },
            ...
        ],
        "notes": "..."
    }
    """
    prep = preprocess_text(text)
    doc: Doc = prep["doc"]

    events: List[MedicalEvent] = []

    for sent in doc.sents:
        entities = _extract_entities_for_sentence(doc, sent)
        actor, target = _get_actor_and_target(sent, entities)
        action = _get_action(sent)
        obj = _get_object(sent, entities)
        dosage = entities["dosages"][0] if entities["dosages"] else None
        reason = _get_reason(sent, entities)

        event = MedicalEvent(
            sentence=sent.text.strip(),
            actor=actor,
            action=action,
            object=obj,
            target=target,
            dosage=dosage,
            reason=reason,
        )
        events.append(event)

    return {
        "text": text,
        "events": [e.to_dict() for e in events],
        "notes": (
            "This is a heuristic clinical relation extractor built on top of spaCy. "
            "For production use, you would likely want to fine‑tune models on real clinical corpora."
        ),
    }

