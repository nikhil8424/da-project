from __future__ import annotations

from typing import Any, Dict, List, Tuple

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Dense, InputLayer
from tensorflow.keras.optimizers import Adam


EVENT_LABELS: List[str] = [
    "Prescription",
    "Diagnosis",
    "Procedure",
    "Admission",
    "Discharge",
    "Observation",
]


def _create_training_data() -> Tuple[List[str], List[str]]:
    """
    Create a small synthetic training set for prototype purposes.

    In a real system you would train on a large, labeled clinical corpus.
    """
    texts: List[str] = []
    labels: List[str] = []

    # Prescription
    texts += [
        "The patient was prescribed 500mg Amoxicillin by Dr. Sharma due to bacterial infection.",
        "Dr. Smith started the patient on 10mg lisinopril once daily.",
        "Medication order: paracetamol 1g every 6 hours for pain.",
    ]
    labels += ["Prescription"] * 3

    # Diagnosis
    texts += [
        "The final diagnosis was community acquired pneumonia.",
        "He was diagnosed with type 2 diabetes mellitus.",
        "Assessment: acute exacerbation of chronic heart failure.",
    ]
    labels += ["Diagnosis"] * 3

    # Procedure
    texts += [
        "The patient underwent laparoscopic cholecystectomy.",
        "An MRI of the brain was performed.",
        "Scheduled for colonoscopy tomorrow morning.",
    ]
    labels += ["Procedure"] * 3

    # Admission
    texts += [
        "The patient was admitted for evaluation of chest pain.",
        "She was brought to the hospital and admitted to the ICU.",
        "Admitted to the medical ward for further management.",
    ]
    labels += ["Admission"] * 3

    # Discharge
    texts += [
        "The patient was discharged home in stable condition.",
        "He was discharged with follow up in two weeks.",
        "Discharge summary: patient stable, to continue medications.",
    ]
    labels += ["Discharge"] * 3

    # Observation
    texts += [
        "The patient is under observation in the emergency department.",
        "Plan: observe overnight for any deterioration.",
        "Kept for observation due to mild head injury.",
    ]
    labels += ["Observation"] * 3

    return texts, labels


def _build_and_train_model():
    """
    Build a simple feed‑forward neural network classifier on top of TF‑IDF features.
    """
    texts, labels = _create_training_data()

    vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=1)
    X = vectorizer.fit_transform(texts)

    label_encoder = LabelEncoder()
    y = label_encoder.fit_transform(labels)

    input_dim = X.shape[1]
    num_classes = len(label_encoder.classes_)

    model = Sequential(
        [
            InputLayer(input_shape=(input_dim,)),
            Dense(64, activation="relu"),
            Dense(32, activation="relu"),
            Dense(num_classes, activation="softmax"),
        ]
    )
    model.compile(
        optimizer=Adam(learning_rate=0.001),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )

    # Train on the small synthetic dataset.
    model.fit(X.toarray(), y, epochs=30, batch_size=4, verbose=0)

    return vectorizer, model, label_encoder


_VECTORIZER, _MODEL, _LABEL_ENCODER = _build_and_train_model()


def classify_medical_event(text: str) -> Dict[str, Any]:
    """
    Classify a clinical sentence into one of the supported medical event types.

    Returns a JSON‑serializable dict:
    {
        "prediction": "Prescription",
        "confidence": 0.94,
        "all_scores": {
            "Prescription": 0.94,
            "Diagnosis": 0.03,
            ...
        }
    }
    """
    if not text or not text.strip():
        raise ValueError("Input text must be a non‑empty string.")

    X = _VECTORIZER.transform([text]).toarray()
    probs: np.ndarray = _MODEL.predict(X, verbose=0)[0]

    class_indices = {cls: idx for idx, cls in enumerate(_LABEL_ENCODER.classes_)}
    predicted_idx = int(np.argmax(probs))
    predicted_label = _LABEL_ENCODER.inverse_transform([predicted_idx])[0]

    all_scores = {
        label: float(probs[class_indices[label]])
        for label in _LABEL_ENCODER.classes_
    }

    confidence = float(all_scores[predicted_label])

    return {
        "prediction": predicted_label,
        "confidence": confidence,
        "all_scores": all_scores,
    }

