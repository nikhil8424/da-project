from __future__ import annotations

from typing import Any, Dict, List

import spacy

_NLP = None


def load_spacy_model():
    """
    Load a spaCy model, preferring a clinical / scientific model if available.

    Tries, in order:
    - en_core_sci_sm  (SciSpacy, if installed)
    - en_core_web_sm  (default English model)
    """
    global _NLP
    if _NLP is not None:
        return _NLP

    model_candidates = ["en_core_sci_sm", "en_core_web_sm"]
    last_error: Exception | None = None

    for name in model_candidates:
        try:
            _NLP = spacy.load(name)
            break
        except Exception as err:  # noqa: BLE001
            last_error = err

    if _NLP is None:
        raise RuntimeError(
            "Could not load a spaCy language model. "
            "Please install one, for example:\n"
            "  python -m spacy download en_core_web_sm\n"
            "or install SciSpacy and a clinical model like en_core_sci_sm."
        ) from last_error

    return _NLP


def preprocess_text(text: str) -> Dict[str, Any]:
    """
    Run basic preprocessing on raw clinical text.

    Returns a dictionary containing:
    - doc: spaCy Doc object
    - sentences: list of sentence texts
    - tokens: list of raw tokens
    - lemmas: list of token lemmas
    """
    nlp = load_spacy_model()
    doc = nlp(text)

    sentences: List[str] = [sent.text.strip() for sent in doc.sents]
    tokens: List[str] = [token.text for token in doc]
    lemmas: List[str] = [token.lemma_ for token in doc]

    return {
        "doc": doc,
        "sentences": sentences,
        "tokens": tokens,
        "lemmas": lemmas,
    }

