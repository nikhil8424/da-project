## Clinical NLP Decision Support Prototype

This project is a small clinical NLP prototype that:

- **Extracts structured medical relations** from unstructured clinical text using spaCy.
- **Classifies medical events** (Prescription, Diagnosis, Procedure, Admission, Discharge, Observation) using an ANN with Dense layers and Softmax.
- **Provides a Streamlit UI** for interactive analysis.

### Project Structure

- `preprocessing.py`: spaCy loading and basic preprocessing (tokenization, lemmatization, sentence segmentation).
- `relation_extractor.py`: syntactic and semantic analysis plus rule‑based extraction of clinical relations.
- `classifier.py`: ANN classifier on top of TF‑IDF features using TensorFlow/Keras.
- `app.py`: Streamlit dashboard integrating the extractor and classifier.
- `requirements.txt`: Python dependencies.
- `relations_log.csv`: (created at runtime) stores extracted relations for each analyzed text.

### Installation

1. **Create and activate a virtual environment (recommended)**.

2. **Install dependencies**:

```bash
pip install -r requirements.txt
```

3. **Install a spaCy language model** (if you do not already have one):

```bash
python -m spacy download en_core_web_sm
```

Optionally, you can install SciSpacy and a clinical model such as `en_core_sci_sm` and the code will prefer it automatically.

### Running the Streamlit App

From the project directory:

```bash
streamlit run app.py
```

Then open the URL shown in the terminal (typically `http://localhost:8501`) in your browser.

### Core Functions

- **Relation extraction**

  - `extract_medical_relations(text: str) -> dict` (in `relation_extractor.py`)
  - Uses:
    - tokenization, lemmatization, sentence segmentation (via `preprocessing.py`)
    - POS tagging and dependency parsing (spaCy)
    - heuristics for:
      - Actor (doctor, agent, or subject)
      - Action (main verb)
      - Object (drug / procedure / direct object)
      - Target (patient)
      - Dosage
      - Reason

- **Event classification**

  - `classify_medical_event(text: str) -> dict` (in `classifier.py`)
  - Pipeline:
    - TF‑IDF vectorization (scikit‑learn)
    - Feed‑forward neural network with Dense layers and Softmax (TensorFlow/Keras)
    - Returns:
      - `prediction`: highest‑probability event type
      - `confidence`: probability of the predicted class
      - `all_scores`: probability for each event type

### Example

Input:

> The patient was prescribed 500mg Amoxicillin by Dr. Sharma due to bacterial infection.

Typical extracted relation (simplified):

- **Actor**: `Dr. Sharma`
- **Action**: `prescribe`
- **Object**: `Amoxicillin`
- **Target**: `patient`
- **Dosage**: `500mg`
- **Reason**: `bacterial infection`

Classification output (example):

```json
{
  "prediction": "Prescription",
  "confidence": 0.94,
  "all_scores": {
    "Prescription": 0.94,
    "Diagnosis": 0.03,
    "Procedure": 0.02,
    "Admission": 0.005,
    "Discharge": 0.005,
    "Observation": 0.000
  }
}
```

### Notes and Next Steps

- This is a **prototype** using a small synthetic training set for the classifier and simple rule‑based extraction. For a production Clinical Decision Support system, you would:
  - Train on a large, labeled clinical dataset.
  - Use domain‑specific models (e.g., SciSpacy with clinical NER models).
  - Consider additional features such as knowledge‑graph construction and REST API endpoints.

