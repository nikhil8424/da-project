from __future__ import annotations

import pathlib
from typing import Any, Dict, List

import pandas as pd
import streamlit as st

from relation_extractor import extract_medical_relations
from classifier import classify_medical_event


RELATIONS_CSV = pathlib.Path("relations_log.csv")


def _store_relations(text: str, events: List[Dict[str, Any]]) -> None:
    """
    Append extracted relations to a CSV file for later analysis.
    """
    rows: List[Dict[str, Any]] = []
    for event in events:
        row = {
            "text": text,
            "sentence": event.get("sentence"),
            "actor": event.get("actor"),
            "action": event.get("action"),
            "object": event.get("object"),
            "target": event.get("target"),
            "dosage": event.get("dosage"),
            "reason": event.get("reason"),
            "event_type": event.get("event_type"),
        }
        rows.append(row)

    df_new = pd.DataFrame(rows)
    if RELATIONS_CSV.exists():
        df_existing = pd.read_csv(RELATIONS_CSV)
        df_out = pd.concat([df_existing, df_new], ignore_index=True)
    else:
        df_out = df_new
    df_out.to_csv(RELATIONS_CSV, index=False)


def main() -> None:
    st.set_page_config(
        page_title="Clinical NLP Decision Support",
        layout="wide",
    )

    st.markdown(
        "<h2 style='text-align: center; color:#1b4b72;'>"
        "Clinical NLP Decision Support Prototype"
        "</h2>",
        unsafe_allow_html=True,
    )
    st.markdown(
        "<p style='text-align: center; color:#555;'>"
        "Extract structured medical relations and classify clinical events from unstructured text."
        "</p>",
        unsafe_allow_html=True,
    )

    st.markdown("---")

    col_input, col_output = st.columns([1, 2])

    with col_input:
        st.subheader("Input Clinical Text")
        default_example = (
            "The patient was prescribed 500mg Amoxicillin by Dr. Sharma due to bacterial infection."
        )
        text = st.text_area(
            "Enter one or more clinical sentences",
            value=default_example,
            height=180,
        )
        analyze_clicked = st.button("Analyze")

    if analyze_clicked and text.strip():
        with st.spinner("Analyzing clinical text..."):
            relations = extract_medical_relations(text)
            events = relations.get("events", [])

            classification = classify_medical_event(text)

            # Attach predicted event type to each event for convenience.
            for event in events:
                event["event_type"] = classification["prediction"]

            _store_relations(text, events)

        with col_output:
            st.subheader("Extracted Medical Relation(s)")
            if not events:
                st.info("No events detected.")
            else:
                for idx, event in enumerate(events, start=1):
                    st.markdown(f"**Sentence {idx}:** {event.get('sentence')}")
                    rel_df = pd.DataFrame(
                        [
                            ["Actor", event.get("actor")],
                            ["Action", event.get("action")],
                            ["Object", event.get("object")],
                            ["Target", event.get("target")],
                            ["Dosage", event.get("dosage")],
                            ["Reason", event.get("reason")],
                            ["Event Type", event.get("event_type")],
                        ],
                        columns=["Role", "Value"],
                    )
                    st.table(rel_df)

            st.subheader("Predicted Event Type")
            pred = classification["prediction"]
            conf = classification["confidence"]
            st.markdown(
                f"""
                <div style="
                    padding: 1rem;
                    border-radius: 8px;
                    background-color: #e8f4ff;
                    border: 1px solid #c5e0ff;
                ">
                    <span style="font-weight:600;color:#1b4b72;">{pred}</span>
                    <span style="color:#555;"> (confidence {conf:.2f})</span>
                </div>
                """,
                unsafe_allow_html=True,
            )

            st.subheader("All Probability Scores")
            scores = classification["all_scores"]
            scores_df = pd.DataFrame(
                {
                    "Event Type": list(scores.keys()),
                    "Score": list(scores.values()),
                }
            ).sort_values("Score", ascending=False)
            st.dataframe(scores_df.style.highlight_max(subset=["Score"], color="#d0ebff"))
            st.bar_chart(scores_df.set_index("Event Type"))

            st.caption(relations.get("notes", ""))


if __name__ == "__main__":
    main()

